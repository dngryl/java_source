package com.simple.Ex;

import java.util.Scanner;

public class Ex05 {

	public static void main(String[] args) {
		// 최댓값 구하기 (두 수)
		// 두 정수를 입력받아 더 큰 수를 출력하세요.
		
		// 데이터 입력
		int num1 = 0;
		int num2 = 0;
		int result = 0; // int result = ""; 이렇게 쓰면 문자를 결과로 출력
		Scanner kbd = new Scanner(System.in);
		
		System.out.print("첫번째 숫자를 입력하세요: ");
		num1 = kbd.nextInt();
		
		System.out.print("두번째 숫자를 입력하세요: ");
		num2 = kbd.nextInt();
		
		// 데이터 처리
		if (num1 > num2) {
			result = num1;
		}else {
			result = num2;
		}
		
		// 데이터 출력
		System.out.print("더 큰 수는?: "+ result);
		
	}

}
