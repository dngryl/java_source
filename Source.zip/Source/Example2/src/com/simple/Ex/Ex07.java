package com.simple.Ex;

import java.util.Scanner;

public class Ex07 {

	public static void main(String[] args) {
		// 요일 출력하기
		// 1~7 사이의 숫자를 입력받아 1은 월요일, 2는 화요일 … 7은 일요일을 출력하세요.
		
		// 데이터 입력
		int day = 0;
		String result = "";
		
		Scanner kbd = new Scanner(System.in);
		
		System.out.print("1~7 중에서 숫자를 입력하세요: ");
		day = kbd.nextInt();

		// 데이터 처리
		if (day == 1) {
			result = "월요일";
		}else if (day == 2){
			result = "화요일";
		}else if (day == 3){
			result = "수요일";
		}else if (day == 4){
			result = "목요일";
		}else if (day == 5){
			result = "금요일";
		}else if (day == 6){
			result = "토요일";
		}else if (day == 7 ) {
			result = "일요일";	
		}else {
			result = "1~7 중에서 숫자를 입력하세요.";
		}
		// 데이터 출력
		System.out.print(result);
		
	}

}
