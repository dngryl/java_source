package com.simple.loop;

public class LoopWhile {

	public static void main(String[] args) {
		// while: 조건식이 참이면 루프를 반복
		int i;
		for (i = 0; i < 10; i++) { // for문 정해진 양식
			System.out.println("i: " + (i + 1));
		}

		i = 0;
		while (i < 10) {
			i++; // i는 제어목적의 변수
			System.out.println("i: " + i);
		}

		// 1부터 n까지 숫자를 더해가면서 그 합이 100이상이 될 때까지 반복하세요.
		i = 0;
		int sum = 0;
		int count = 0;
		int finalCount = 0;

		while (sum < 100) {
			sum = sum + i;
			System.out.println("합계: " + sum);
			System.out.println("i: " + i);
			i++;
			finalCount = count++;
			//count++;
		}

		// 반복횟수 출력
		System.out.println("반복 횟수: "+count);
		System.out.println("최종 반복 횟수: "+finalCount);
		
		
	}

}
