package com.simple.condition;

public class Sungjuk01 {

	public static void main(String[] args) {
		// if 제어문
		// 성적(국어, 영어, 수학)을 키보드로 입력 받아서
		// 총점, 평균, 등급을 구한다.
		// 등급: 수, 우, 미, 양, 가
		
		// 데이터 입력
		// 입출력 변수 준비
		int kor, eng, mat; // 과목 변수
		int tot; // 총점 변수
		double avg; // 평균 변수
		char grade; // 등급 변수

		kor = 40;
		eng = 80;
		mat = 90;
				
		// 데이터 처리
		// 총점, 평균 처리
		tot = kor+eng+mat;
		avg = (double)tot/3;
		
		// 등급 처리(수~가)
		if(avg >= 90) {
			grade = '수';
		}else if(avg >= 80) {
			grade = '우';
		}else if(avg >= 70) {
			grade = '미';
    	}else if(avg >= 60) {
    		grade = '양';
    	}else {
			grade = '가';
    	}
	
			
		// 데이터 출력
		System.out.println("----------------------------");
		System.out.println("국어  영어  수학  총점  평균  등급");
		System.out.printf("%d %4d %4d %4d %2.2f %2s \n", //실수는 f를 붙이고 원하는 소수점자리는 .*으로 작성
							kor,eng,mat,tot,avg,grade); // 가운데 숫자는 칸 몇 칸 사용할 지.
		System.out.println("----------------------------");
		
	}
}