package com.sample.io;

import java.util.Scanner; // 새로운 클래스, 스캐너 작성영역

public class ScannerEx01 {

	public static void main(String[] args) {
		
		// 사용자로부터 키보드로 값을 입력받는다
		String name = ""; //"" 키보드 입력을 받기 위한 공란
		int age;
				
		Scanner kbd = new Scanner(System.in); // system.in은 시스템의 입력장치를 뜻함

		System.out.print("이름: ");
		name = kbd.nextLine(); // 키보드에서 글자를 입력받아서 넘겨줌
		
		System.out.print("나이: ");
		//age = Integer.parseInt(kbd.nextLine());
		age = kbd.nextInt(); // 키보드에서 글자를 입력받아서 넘겨줌

		System.out.println("이름:"+name);
		System.out.println("나이:"+age);
	}

}
