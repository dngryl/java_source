package com.simple.operator;

public class OperatorRelation2 {

	public static void main(String[] args) {
		
		// 논리 연산자
		// &&, ||, !
		// 자격증 시험 합격여부 판단
		// 1차 필기 60점 이상이고 과목은 국어, 영어, 수학
		// 과목점수는 최소 40점 이상
		
		// 입출력 변수 설계
		int kor = 52;
		int eng = 40;
		int mat = 80;
		double avg;
		
		//String pass = "합격";
		boolean pass1; // 과목과락
		boolean pass2; // 필기합격
		boolean pass3; // 최종합격
		
		// 과목과락 체크
		pass1 = (kor >= 40) && // &&: 모두 참일 경우 true, 그렇지 않을 경우 false
				(eng >= 40) && 
				(mat >= 40);
						
		// 평균 점수
		avg = (double)(kor+eng+mat)/3; //int로 정수 선언 되었기 때문에 double 붙여줘야함
		pass2 = avg >= 60;
		
		// 최종 결과
		pass3 = pass1 && avg >= 60;
		
		// 결과 출력 (출력 단계)
		System.out.println("국어: "+kor);
		System.out.println("영어: "+eng);
		System.out.println("수학: "+mat);
		System.out.println("평균: "+avg);
		System.out.println("과락 면제: "+pass1);
		System.out.println("필기 합격: "+pass2);
		System.out.println("최종 합격: "+pass3);
		
	}

}