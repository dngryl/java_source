package com.simple.exam;

import java.util.Scanner;

public class exam2 {

	public static void main(String[] args) {
		// 자리수 합 구하기
		// 사용자로부터 정수를 입력받아 각 자리수를 모두 더한 합을 출력하시오.

		// 입력
		Scanner kbd = new Scanner(System.in);
		int num = kbd.nextInt();
		int sum = 0;
		
		// 처리
		

		// 출력
	
		
	}

}
