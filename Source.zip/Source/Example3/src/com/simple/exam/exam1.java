package com.simple.exam;

import java.util.Scanner;

public class exam1 {

	public static void main(String[] args) {
		// 1부터 N까지의 수 중 소수 판별하기
		// 사용자로부터 정수 N을 입력받아 1부터 N까지의 수 중 소수만 출력하시오.

		// 입력
		Scanner kbd = new Scanner(System.in);
		int n = kbd.nextInt();

		// 처리
		for (int i = 2; i <= n; i++) {
			boolean prime = true;

			for (int j = 2; j < i; j++) {
				if (i % j == 0) {
					prime = false;
					break;
				}

			}

			// 출력
			if (prime)
				System.out.print(i + " ");
		}
	}

}
