package com.simple;

public class DataType {

	public static void main(String[] args) {
		byte num1 = 120;
		byte num2 = (byte)(num1 + 5);
		int num3 = num1 + 5;
		
		System.out.println("num2:"+ num2);
		System.out.println(num3);
		
		
		


	}

}
