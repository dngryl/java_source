package com.simple;

public class DataType3 {

	public static void main(String[] args) {
	
		float num1 = 65.20298f; //float은 뒤에 f 붙여줘야함.
		double num2 = 876.4565456456;
		
		System.out.println(num1);
		System.out.println(num2);

	}

}