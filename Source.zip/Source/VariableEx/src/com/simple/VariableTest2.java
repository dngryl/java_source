package com.simple;

public class VariableTest2 {

	public static void main(String[] args) {
		
		String name; // 변수 선언 (string은 문자열)
		int age;
		
		name = "홍길동";
		age = 20;
		
		System.out.printf("이름: %s 나이: %d",name,age);
		// %s는 문자열, %d는 숫자열(정수)
		// printf는 서식문자열로 서식 지정자(%s, %d, %f 등)가 포함
		System.out.println();
		
		name = "박보검";
		age = 35;
		
		System.out.printf("이름: %s 나이: %d",name,age);
		
	}

}
