package com.simple;

public class VariableTest {

	public static void main(String[] args) {
		
		String name; // 변수 선언 (string은 문자열)
		int age;
		
		name ="홍길동";
		age = 25;
		
		System.out.print("이름: "+name);
		System.out.print(", 나이: "+age); 
		//ln 안붙이면 줄 나누지 않음
		System.out.println();

		name = "박보검";
		age = 35; 
		
		System.out.print("이름: "+name);
		System.out.print(", 나이: "+age); 
		
		
	}

}
