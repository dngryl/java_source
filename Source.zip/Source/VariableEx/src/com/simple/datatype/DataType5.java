package com.simple.datatype;

public class DataType5 {

	public static void main(String[] args) {
		// 출력제어 특수문자(이스케이프 문자)
		
		System.out.printf("%s \n","Java Program");
		System.out.println("Java\nProgram");
		System.out.print("Java Program\n");
		System.out.println("Java Program\n");
		System.out.println("Java\rProgram\n");
		System.out.println("Java\bProgram\n");
		System.out.println("Java\tProgram\n");
		
		// ",',\
		System.out.println("Java \"Hello\" Program\n");
		System.out.println("Java 'Hello' Program\n");
		System.out.println("Java \\Hello\\ Program\n");
	}

}
