package com.simple.datatype;

public class DataType4 {

	public static void main(String[] args) {
		// 부울리언 자료형
		// 남/여, 찬/반, 성공/실패 등
		
		//String pass = "합격"; //합격여부 합격기준
		boolean pass = true; //합격여부 합격기준
		//boolean pass = false; //합격여부 합격기준
		System.out.println("합격여부: "+pass);
		
		// UTF 문자셋 
		char name = '\uae00';
		
		System.out.println("name"+name);

		

	}

}
