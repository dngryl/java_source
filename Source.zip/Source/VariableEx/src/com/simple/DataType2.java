package com.simple;

public class DataType2 {

	public static void main(String[] args) {
		byte num1 = 120;
		short num2 = 30000;
		double num3 = 210.5;
		long num4 = 123456789999999999L; //롱 타입은 뒤에 L을 붙여줘야함.
		char pass = 'a';
		String pass1 = "통과";
		
		System.out.println(num1);
		System.out.println(num2);
		System.out.println(num3);
		System.out.println(num4);
		System.out.println(pass);
		System.out.println(pass1);

	}

}
