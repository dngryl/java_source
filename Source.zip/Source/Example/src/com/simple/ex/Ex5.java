package com.simple.ex;

import java.util.Scanner;

public class Ex5 {

	public static void main(String[] args) {
		// 최댓값 구하기 (두 수)
		// 두 정수를 입력받아 더 큰 수를 출력하세요.

		// 데이터 입력
		int A = 0;
		int B = 0;
		String result = "";
		Scanner kbd = new Scanner(System.in);

		System.out.print("A 숫자: ");
		A = kbd.nextInt();
		
		System.out.print("B 숫자: ");
		B = kbd.nextInt();

		// 데이터 처리
		if(A > B) {
			result = "A";
		}else {
			result = "B";
		}

		// 데이터 출력
		System.out.println("더 큰 수: " + result);

	}

}
