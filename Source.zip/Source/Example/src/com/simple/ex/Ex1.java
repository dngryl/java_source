package com.simple.ex;

import java.util.Scanner;

public class Ex1 {

	public static void main(String[] args) {
		// 짝수/홀수 판별하기
		// 사용자로부터 정수를 입력받아 짝수인지 홀수인지 출력하세요.

		// 데이터 입력
		int num = 0; // 정수를 키보드 입력받음
		String result = "";
		Scanner kbd = new Scanner(System.in); // 스캐너 임포트

		System.out.print("숫자를 입력하세요: ");
		num = kbd.nextInt(); // num = 키보드 외부입력 연결
								// kbd.nextInt();는 int, String은 nextLine

		// 데이터 처리
		int num_ = num % 2;
		if (num_ == 0) {	// 수식 등호는 무조건 ==로
			result = "짝수";
		} else {
			result = "홀수";
		}

		// 데이터 출력
		System.out.println("숫자: " + num);
		System.out.println("결과: " + result);
	}

}
