package com.simple.ex;

import java.util.Scanner;

public class Ex6 {

	public static void main(String[] args) {
		// 최댓값 구하기 (세 수)
		// 세 정수를 입력받아 가장 큰 수를 출력하세요.

		// 데이터 입력
		int A = 0;
		int B = 0;
		int C = 0;
		int result = 0;
		Scanner kbd = new Scanner(System.in);
		
		boolean A_;
		boolean B_;
		boolean C_;
		
		System.out.print("첫번째 숫자: ");
		A = kbd.nextInt();
		
		System.out.print("두번째 숫자: ");
		B = kbd.nextInt();
		
		System.out.print("세번째 숫자: ");
		C = kbd.nextInt();

		// 데이터 처리
		A_ = (A > B) && (A > C);
		B_ = (B > A) && (B > C);
		C_ = (C > A) && (C > B);
		
		if (A_) {
			result = A;
		}else if(B_) {
			result = B;
		}else {
			result = C;
		}
	
		
		// 데이터 출력
		System.out.println("가장 큰 수: " + result);
		
	}

}
