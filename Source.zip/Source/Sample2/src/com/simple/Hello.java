package com.simple;

public class Hello {
	
	public static void main(String[] args) {
		System.out.println("안녕 자바");
	}
		

}
